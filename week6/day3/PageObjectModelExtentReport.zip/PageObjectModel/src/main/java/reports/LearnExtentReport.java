package reports;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {

	public static void main(String[] args) throws IOException {
		//step -1 set the path for report
		ExtentHtmlReporter wb=new ExtentHtmlReporter("./Reports/extentReports.html");
		
		//retain the existing report
		wb.setAppendExisting(true);
		
		//step -2 create object for ExtentReports
		ExtentReports er=new ExtentReports();
		
		//step -3 connect step 1 & step 2
		er.attachReporter(wb);
		
		//step -4 testcase details
		ExtentTest test = er.createTest("LoginPage", "Test Login data for leaftaps application");
		test.assignAuthor("Dilip");
		test.assignCategory("Sanity");
		
		//step -5 Test step level status
		test.pass("Enter the username is successful");
		test.pass("Enter the password is successful");
		test.fail("Login is not Click");
		test.pass("crmsfa is clicked", MediaEntityBuilder.createScreenCaptureFromPath(".././SnapShot/image.png").build());
		
		ExtentTest test1 = er.createTest("CreateLeadPage", "Test  Lead created  for leaftaps application");
		test1.assignAuthor("Anburaj");
		test1.assignCategory("smoke testing");
		
		//step -5 Test step level status
		test1.pass("Enter the username is successful");
		test1.pass("Enter the password is successful");
		test1.pass("Login is Click successful",MediaEntityBuilder.createScreenCaptureFromPath(".././SnapShot/image1.png").build());
		test1.pass("crmsfa is clicked", MediaEntityBuilder.createScreenCaptureFromPath(".././SnapShot/image.png").build());
		
		//step 6 close the report
		er.flush();
		System.out.println("Done");
		
	}

}
