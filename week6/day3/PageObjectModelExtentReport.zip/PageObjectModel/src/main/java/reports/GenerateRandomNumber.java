package reports;

public class GenerateRandomNumber {

	public static void main(String[] args) {
		int random = (int)(Math.random()*99999);
		
		System.out.println(random);
	}
}

//97184
//55591