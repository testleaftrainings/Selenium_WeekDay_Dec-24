package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Then;

public class HomePage extends ProjectSpecificMethod{

	@Then("Verify the title of the page")
	public HomePage verifyTitle() {	
		try {
			String title = getDriver().getTitle();

			if(title.contains("Leaftaps")) {
				System.out.println("Login is Successful");
			}else
			{
				System.out.println("Login is not Successful");
			}
			test.info("Pass");
		} catch (Exception e) {
			test.info("fail");
		}
		return this;

	}
	/*
	 * public HomePage(ChromeDriver driver) { this.driver=driver; }
	 */


	public MyHomePage clickCrmsfa() throws IOException {
		try {
			getDriver().findElement(By.linkText("CRM/SFA")).click();
			reportStep("Crmsfa is clicked successful", "pass");
		} catch (Exception e) {
			System.out.println(e);
			reportStep("crmsfa is not clicked successful", "fail");
		}
		return new MyHomePage();
	}


	public LoginPage clickLogoutbutton() throws IOException {
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			reportStep("Logout is  successful", "pass");

		} catch (Exception e) {
			System.out.println(e);
			reportStep("Logout is not successful", "fail");

			
		}
		return new LoginPage();

	}
}
