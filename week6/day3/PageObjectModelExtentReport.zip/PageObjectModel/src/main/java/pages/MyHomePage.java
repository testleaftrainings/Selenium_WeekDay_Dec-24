package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class MyHomePage  extends ProjectSpecificMethod{

	public MyLeadsPage clickOnLeads() throws IOException {
		try {
			getDriver().findElement(By.linkText(pro.getProperty("MyHomePage.Leads"))).click();
			reportStep("Leads button is clicked", "pass");

		} catch (Exception e) {

			System.out.println(e);
			reportStep("Leads button is not clicked", "fail");
		}
		return new MyLeadsPage();
	}






	public void clickOnContacts() {
		getDriver().findElement(By.linkText("Contacts")).click();

	}

	public void clickOnAccounts() {
		getDriver().findElement(By.linkText("Accounts")).click();

	}


}
