package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod {

	
	/*

	 * //step 2 create own constructor call all the pages with driver value public
	 * LoginPage(ChromeDriver driver) { this.driver=driver; }
	 */	
	
@When("Enter the username as Demosalesmanager")
	public LoginPage enterUserName() throws IOException {
		try {
			getDriver().findElement(By.id("username")).sendKeys(pro.getProperty("username"));
			reportStep("Entered UserName as Successful", "pass");
			
		} catch (Exception e) {
			System.out.println(e);
			reportStep("Entered UserName as not Successful", "fail");
		}	
		return this;
	}
	
@And("Enter the password as crmsfa")
	public LoginPage enterPassword() throws IOException {
		try {
			getDriver().findElement(By.id("password")).sendKeys(pro.getProperty("password"));
			reportStep("Entered Password as Successful", "pass");
		} catch (Exception e) {
			System.out.println(e);
			reportStep("Entered Password as not Successful", "fail");

		}
		return this;
	}
	
	@And("Click on LoginButton")
	public HomePage clickOnLoginButton() throws IOException {
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			reportStep("Login as Successful", "pass");

		} catch (Exception e) {
			System.out.println(e);
			reportStep("Login as not Successful", "fail");

		}
		//step 3 pass variable inside constructor call
		return new HomePage();
	}
	
	
}
