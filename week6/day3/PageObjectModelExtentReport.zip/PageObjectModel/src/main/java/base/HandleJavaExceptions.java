package base;

public class HandleJavaExceptions {

	public static void main(String[] args) {
		
		int[] num= {8,9,78,66,43,2,6};
		
		try {
			System.out.println(num[4]);
		}catch(ArrayIndexOutOfBoundsException a) {
		System.out.println(num[1]);	
		}
		catch (Exception e) {
			System.out.println(e);
			System.out.println(num[3]);
		}finally {
			System.out.println("Run every time");
		}
		
		System.out.println("Done");

	}

}
