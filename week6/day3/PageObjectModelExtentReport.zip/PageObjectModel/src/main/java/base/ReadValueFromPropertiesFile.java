package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ReadValueFromPropertiesFile {

	public static void main(String[] args) throws IOException {
		//step 1- set path of the properties file
		FileInputStream val=new FileInputStream("src/main/resources/French.properties");
		
		//step2 - create object for Properties Class
		Properties pro=new Properties();
		
		//step3 load value from properties file to Class
		pro.load(val);
		
		//step4 read value from properties file
		String property = pro.getProperty("MyHomePage.Leads");
		System.out.println(property);

	}

}
