package base;

public class Browser {

	int num;
	boolean status;
	
	//Default or Zero agrs constructor
	public Browser() {
		System.out.println("I am Default constructor");
	}
	
	//parameterized
	public Browser(int num,boolean status) {
		this();
		System.out.println("i am parameterized constructor");
		this.num=num;
		this.status=status;
		System.out.println(num+" "+status);
		//this - keyword -current class->variable,method and constructor
	}
	
	
	public static void main(String[] args) {
	//	Browser b=new Browser();
		Browser b1=new Browser(25,true);
		
		/*
		 * System.out.println("Default value for int :"+b.num);
		 * System.out.println("Default value for boolean :"+b.status);
		 */
	
	}
	
	
}
