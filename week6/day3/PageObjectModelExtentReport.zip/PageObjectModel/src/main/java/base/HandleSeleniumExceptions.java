package base;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleSeleniumExceptions {

	public static void main(String[] args) throws InterruptedException {

		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.get("http://leaftaps.com/opentaps/control/main");
		
		try {
			driver.findElement(By.id("username")).sendKeys("DemoCsr");
			//throw -user define data
		throw new NoSuchElementException("kindly check the value");
		
		
		} catch (Exception e) {
		System.out.println(e);
		driver.findElement(By.id("username")).sendKeys("DemoSalesManager");

		}
		
		Thread.sleep(3000);
		
		
		driver.findElement(By.id("password")).sendKeys("crmsfa");
	}

}
