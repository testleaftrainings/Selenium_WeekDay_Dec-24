package runner;

import org.testng.annotations.BeforeTest;

import base.ProjectSpecificMethod;
import io.cucumber.testng.CucumberOptions;



@CucumberOptions(features="src/main/java/features/Login.feature",
glue="pages",publish=true)

public class TC_003_LoginWithCucumber extends ProjectSpecificMethod{

	@BeforeTest
	public void setValues() {
		testName="Login with Cucumber";
		testDescription="Login data";
		testAuthor="Dilip";
		testCategory="Sanity Testing";
	}
	
	
}
