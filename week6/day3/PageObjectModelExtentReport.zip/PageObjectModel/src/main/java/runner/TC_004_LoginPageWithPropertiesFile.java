package runner;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC_004_LoginPageWithPropertiesFile extends ProjectSpecificMethod{
	
	@BeforeTest
	public void setValues() {
		testName="LoginPage";
		testDescription="Create Extent Report for Login Page";
		testAuthor="Dilip";
		testCategory="Smoke Testing";
	}
	
	
	
	@Test
	public void runLogin() throws IOException {
		//create object LoginPage
		LoginPage lp=new LoginPage();
		//System.out.println(driver);
		lp.enterUserName()
		.enterPassword()
		.clickOnLoginButton()
		.clickCrmsfa()
		
		.clickOnLeads();
	}
	
	

}
