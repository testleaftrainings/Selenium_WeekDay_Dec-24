package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.DataSheet;




public class ProjectSpecificMethod extends AbstractTestNGCucumberTests {
	//step1
	private static final ThreadLocal<RemoteWebDriver> cdDriver=new ThreadLocal<RemoteWebDriver>();
	
	//step2
	public void setDriver() {
		cdDriver.set(new ChromeDriver());
	}
	
	//step 3
	public RemoteWebDriver getDriver() {
		return cdDriver.get();
	}
	
	public String datasheet;
	@BeforeMethod
	public void preCondition() {
		// driver = new ChromeDriver();
		setDriver();
		
		//step4 replace variable driver into getDriver();
		//remove constructor call from all the pages
		
		getDriver().manage().window().maximize();
		getDriver().get("http://leaftaps.com/opentaps/");
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));	
	}
	 
    @AfterMethod
    public void postCondition() {
    	getDriver().close();
    }
    

  	@DataProvider(name="SetValues",indices = {0})
  	public String[][] fetchData() throws IOException{
  		return DataSheet.readExcel(datasheet);
  	}
}
