package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Then;

public class HomePage extends ProjectSpecificMethod{

	@Then("Verify the title of the page")
	public HomePage verifyTitle() {
		String title = getDriver().getTitle();
		
		if(title.contains("Leaftaps")) {
			System.out.println("Login is Successful");
		}else
		{
			System.out.println("Login is not Successful");
		}
		
		return this;
		
	}
	/*
	 * public HomePage(ChromeDriver driver) { this.driver=driver; }
	 */
	
	
	public MyHomePage clickCrmsfa() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage();
	}
	
	
	public LoginPage clickLogoutbutton() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
	return new LoginPage();
	
	}
}
