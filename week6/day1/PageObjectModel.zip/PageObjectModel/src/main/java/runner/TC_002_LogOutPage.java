package runner;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC_002_LogOutPage extends ProjectSpecificMethod{
	
	
	@Test
	public void runLogin() {
		//create object LoginPage
		LoginPage lp=new LoginPage();
		//System.out.println(driver);
		lp.enterUserName("DemoSalesManager")
		.enterPassword("crmsfa")
		.clickOnLoginButton()
		.clickLogoutbutton();
	}
	
	

}
