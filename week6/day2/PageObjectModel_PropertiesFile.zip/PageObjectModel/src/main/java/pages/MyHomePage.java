package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class MyHomePage  extends ProjectSpecificMethod{


	
	
	public MyLeadsPage clickOnLeads() {
		try {
			getDriver().findElement(By.linkText(pro.getProperty("MyHomePage.Leads"))).click();
		} catch (Exception e) {

System.out.println(e);
		}
	return new MyLeadsPage();
	}
	
	
	
	
	
	
	public void clickOnContacts() {
		getDriver().findElement(By.linkText("Contacts")).click();

	}
	
	public void clickOnAccounts() {
		getDriver().findElement(By.linkText("Accounts")).click();

	}
	
	
}
