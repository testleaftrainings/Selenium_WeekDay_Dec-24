package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod {

	/*

	 * //step 2 create own constructor call all the pages with driver value public
	 * LoginPage(ChromeDriver driver) { this.driver=driver; }
	 */	
	
	

//	@When("Enter the username as {string}")
	public LoginPage enterUserName() {
		try {
			getDriver().findElement(By.id("username")).sendKeys(pro.getProperty("username"));
		} catch (Exception e) {
			System.out.println(e);
		}	
		return this;
	}
	
//	@And("Enter the password as {string}")
	public LoginPage enterPassword() {
		try {
			getDriver().findElement(By.id("password")).sendKeys(pro.getProperty("password"));
		} catch (Exception e) {
			System.out.println(e);
		}
		return this;
	}
	
//	@And("Click on LoginButton")
	public HomePage clickOnLoginButton() {
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
		} catch (Exception e) {
			System.out.println(e);
		}
		//step 3 pass variable inside constructor call
		return new HomePage();
	}
	
	
}
