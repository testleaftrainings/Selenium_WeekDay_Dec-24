package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.DataSheet;




public class ProjectSpecificMethod extends AbstractTestNGCucumberTests {

	private static final ThreadLocal<RemoteWebDriver> cdDriver=new ThreadLocal<RemoteWebDriver>();
	


	public void setDriver() {
		cdDriver.set(new ChromeDriver());
	}
	
	
	public RemoteWebDriver getDriver() {
		return cdDriver.get();
	}
	
	public String datasheet;
	public static Properties pro;
	@BeforeMethod
	public void preCondition() throws IOException {
		
		setDriver();	
		FileInputStream val=new FileInputStream("src/main/resources/French.properties");
		pro=new Properties();
		pro.load(val);
		getDriver().manage().window().maximize();
		getDriver().get("http://leaftaps.com/opentaps/");
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));	
	}
	 
    @AfterMethod
    public void postCondition() {
    	getDriver().close();
    }
    

  	@DataProvider(name="SetValues",indices = {0})
  	public String[][] fetchData() throws IOException{
  		return DataSheet.readExcel(datasheet);
  	}
}
