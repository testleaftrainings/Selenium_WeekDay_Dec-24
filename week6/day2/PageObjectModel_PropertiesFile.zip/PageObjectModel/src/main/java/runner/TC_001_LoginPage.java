package runner;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC_001_LoginPage extends ProjectSpecificMethod{
	
	@BeforeTest
	public void readValue() {
		datasheet="Login";
	}
	
	
	
	
	/*
	 * @Test(dataProvider = "SetValues") public void runLogin(String user,String
	 * pass) { //create object LoginPage LoginPage lp=new LoginPage();
	 * //System.out.println(driver); lp.enterUserName(user) .enterPassword(pass)
	 * .clickOnLoginButton() .clickCrmsfa()
	 * 
	 * .clickOnLeads(); }
	 */
	
	

}
