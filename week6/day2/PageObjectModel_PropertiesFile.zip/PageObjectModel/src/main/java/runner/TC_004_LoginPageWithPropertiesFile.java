package runner;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC_004_LoginPageWithPropertiesFile extends ProjectSpecificMethod{
	
	
	@Test
	public void runLogin() {
		//create object LoginPage
		LoginPage lp=new LoginPage();
		//System.out.println(driver);
		lp.enterUserName()
		.enterPassword()
		.clickOnLoginButton()
		.clickCrmsfa()
		
		.clickOnLeads();
	}
	
	

}
