package challenges;

import com.github.javafaker.Faker;

public class FakerData {

	public static void main(String[] args) {

Faker f=new Faker();

String fullName = f.name().fullName();
System.out.println(fullName);

String cellPhone = f.phoneNumber().cellPhone();
System.out.println(cellPhone);

String creditCardNumber = f.business().creditCardNumber();
System.out.println(creditCardNumber);

String fullAddress = f.address().fullAddress();
System.out.println(fullAddress);


	}

}
