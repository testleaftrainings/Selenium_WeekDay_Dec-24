package runner;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC_001_LoginPage extends ProjectSpecificMethod{
	@Test
	public void runLogin() {
		//create object LoginPage
		LoginPage lp=new LoginPage();
		
		lp.enterUserName()
		.enterPassword()
		.clickOnLoginButton()
		.clickCrmsfa()
		.clickOnLeads();
	}
	
	

}
