package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethod;

public class MyHomePage  extends ProjectSpecificMethod{

	public MyLeadsPage clickOnLeads() {
		driver.findElement(By.linkText("Leads")).click();
	return new MyLeadsPage();
	}
	
	
	public void clickOnContacts() {
		driver.findElement(By.linkText("Contacts")).click();

	}
	
	public void clickOnAccounts() {
		driver.findElement(By.linkText("Accounts")).click();

	}
	
	
}
